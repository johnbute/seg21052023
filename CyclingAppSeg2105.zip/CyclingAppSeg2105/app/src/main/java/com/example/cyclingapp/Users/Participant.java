package com.example.cyclingapp.Users;
public class Participant extends Account {
    
    public Participant(String username, String password, String email) {
        super(username, password, email);
    }

}