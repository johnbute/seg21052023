package com.example.cyclingapp.Users;

public class ClubOwner extends Account {
    
    public ClubOwner(String username, String password, String email) {
        super(username, password, email);

    }

    
}
