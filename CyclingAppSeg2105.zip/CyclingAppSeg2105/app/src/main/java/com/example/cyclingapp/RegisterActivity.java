package com.example.cyclingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    private String type = null;

    public void participantsOnClick(View view) {
        type = "P";
    }

    public void clubOrganizerOnClick(View view) {
        type = "CO";
    }

    public void registerOnClick(View view) {
        if (type == null) {
            CharSequence text = "Choose Type";
            int duration = Toast.LENGTH_LONG;
            Toast toast = Toast.makeText(this /* MyActivity */, text, duration);
            toast.show();
        } else if (false) {
            Intent intent = new Intent(getApplicationContext(), WelcomeActivity.class);
            startActivity(intent);
        } else {
            CharSequence text = "Invalid Email or UserName";
            int duration = Toast.LENGTH_LONG;
            Toast toast = Toast.makeText(this /* MyActivity */, text, duration);
            toast.show();
        }
    }

    public void backOnClick(View view) {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }
}