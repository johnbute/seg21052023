package com.example.cyclingapp.Users;

public class Event {
    String title;
    String description;

    public Event(String title, String description, int capacity){

        this.title = title;
        this.description = description;

    }
    
}
